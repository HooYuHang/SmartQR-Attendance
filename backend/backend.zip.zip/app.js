import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import serverless from "serverless-http";

import classRoutes from "./routes/classRoutes.js";
import { verifyToken } from "./middleware/authMiddleware.js";
import authRoutes from "./routes/authRoutes.js";
import studentRoutes from "./routes/studentRoutes.js";
import ipRoutes from "./routes/ipRoutes.js";
import attendanceRoutes from "./routes/attendanceRoutes.js";

dotenv.config();

const app = express();

// Trust proxy (important for IP)
app.set("trust proxy", true);

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB (Lambda-safe)
if (mongoose.connection.readyState === 0) {
  mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("✅ MongoDB connected"))
    .catch(err => console.error("MongoDB error:", err));
}

// Routes
app.use("/api", classRoutes);
app.use("/api/classes", classRoutes);
app.use("/auth", authRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/classes", attendanceRoutes);
app.use("/api", ipRoutes);

// Protected route
app.get("/student/me", verifyToken, (req, res) => {
  res.json({ user: req.user });
});

// Test route
app.get("/", (req, res) => {
  res.json({ message: "SmartQR Attendance API" });
});

// ✅ Lambda handler
export const handler = serverless(app);
